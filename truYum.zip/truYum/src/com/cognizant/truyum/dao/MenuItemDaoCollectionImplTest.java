package com.cognizant.truyum.dao;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import com.cognizant.truyum.model.MenuItem;

public class MenuItemDaoCollectionImplTest {

	private MenuItemDao menuitemdao;
	@Before
	public void setUp() throws Exception {
		menuitemdao = new MenuItemDaoCollectionImpl();
	}

	@After
	public void tearDown() throws Exception {
		menuitemdao = null;
	}

	@Ignore
	public final void testMenuItemDaoCollectionImpl() {
		
	}

	@Test
	public final void testGetMenuItemListAdmin() {
		List<MenuItem> menuitemlist = null;
		try{
			menuitemlist = menuitemdao.getMenuItemListAdmin();
		}catch(Exception e){
			e.printStackTrace();
		}
		for(MenuItem mi : menuitemlist){
			System.out.println(mi);
		}
		assertTrue(menuitemlist.size()>0);
	}

	@Ignore
	public final void testGetMenuItemListCustomer() {
		fail("Not yet implemented");
	}

	@Ignore
	public final void testModifyMenuItem() {
		fail("Not yet implemented");
	}

	@Ignore
	public final void testGetMenuItem() {
		fail("Not yet implemented");
	}

}
