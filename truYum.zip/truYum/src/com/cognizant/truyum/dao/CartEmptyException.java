package com.cognizant.truyum.dao;

public class CartEmptyException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2004925400902599525L;

	public CartEmptyException() {
		// TODO Auto-generated constructor stub
	}

	public CartEmptyException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public CartEmptyException(Throwable message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public CartEmptyException(String message, Throwable arg1) {
		super(message, arg1);
		// TODO Auto-generated constructor stub
	}

	public CartEmptyException(String message, Throwable arg1, boolean arg2, boolean arg3) {
		super(message, arg1, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

}
