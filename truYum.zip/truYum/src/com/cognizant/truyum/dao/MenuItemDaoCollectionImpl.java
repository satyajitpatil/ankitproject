package com.cognizant.truyum.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.cognizant.truyum.model.MenuItem;
import com.cognizant.truyum.util.DateUtil;

public class MenuItemDaoCollectionImpl implements MenuItemDao {

	private static List<MenuItem> menuItemList = null;
	
	public MenuItemDaoCollectionImpl() {
		if(menuItemList == null){
		menuItemList = new ArrayList<MenuItem>();
		MenuItem mi1 = new MenuItem(1,"Sandwhich",99.0f,true,DateUtil.convertToDate("26/03/2019"),"Main course",true);
		MenuItem mi2 = new MenuItem(2,"eggs",99.0f,false,DateUtil.convertToDate("26/03/2019"),"Desert",true);
		MenuItem mi3 = new MenuItem(3,"juice",99.0f,true,DateUtil.convertToDate("26/03/2019"),"Drinks",false);
		
		menuItemList.add(mi1);
		menuItemList.add(mi2);
		menuItemList.add(mi3);
		}
	}
	
	

	@Override
	public List<MenuItem> getMenuItemListAdmin(){
		
		/*for(MenuItem mi:menuItemList){
			System.out.println("detail: "+mi);
		}*/
		
		return menuItemList;
	}

	@Override
	public List<MenuItem> getMenuItemListCustomer() {
		// TODO Auto-generated method stub
        List<MenuItem> menuItemListCustomer = new ArrayList<>();
        Date today = new Date();
        for (MenuItem menuItem : menuItemList) {
             if ((menuItem.getDateOfLaunch().compareTo(today)) <= 0) {
                  if (menuItem.isActive()) {
                        menuItemListCustomer.add(menuItem);
                  }
             }
        }

        return menuItemListCustomer;
	}

	@Override
	public void modifyMenuItem(MenuItem menuItem) {
		// TODO Auto-generated method stub
        menuItemList.set((int) menuItem.getId() - 1, menuItem);
		
		System.out.println(getMenuItem(menuItem.getId()));

	}

	@Override
	public MenuItem getMenuItem(long menuItemId) {
		// TODO Auto-generated method stub
		MenuItem mi = null;
		for (MenuItem m : menuItemList) {
            if(m.getId()==menuItemId){
            	mi = m;
            }
       }
		return mi;
	}

}
