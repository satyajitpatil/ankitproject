package com.cognizant.truyum.model;
import java.util.Date;

import java.text.SimpleDateFormat;

public class DateUtil {
public static Date convertToDate(String date)throws Exception{
	Date convertedDate=new SimpleDateFormat("dd/MM/yyyy").parse(date);
	return convertedDate;
}
}
