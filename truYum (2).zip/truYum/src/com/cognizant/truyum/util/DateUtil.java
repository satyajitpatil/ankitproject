package com.cognizant.truyum.util;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.taglibs.standard.extra.spath.ParseException;

public class DateUtil{
public static Date convertToDate(String date){
	SimpleDateFormat format=new SimpleDateFormat("MM/dd/yyyy");
	Date convertedDate=null;
	try{
	 convertedDate=format.parse(date);
	
	} catch (java.text.ParseException e) {
		
		e.printStackTrace();
	}
	return convertedDate;
}
}
