package com.cognizant.truyum.dao;

import static org.junit.Assert.fail;

import java.util.Iterator;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cognizant.truyum.model.MenuItem;

public class CartDaoCollectionImplTest {
	
	CartDao cartDao;

	@Before
	public void setUp() throws Exception {
		
		cartDao = new CartDaoCollectionImpl();
	}

	@After
	public void tearDown() throws Exception {
		cartDao = null;
	}

	@Test
	public final void testCartDaoCollectionImpl() {
		cartDao = new CartDaoCollectionImpl();
	}

	@Test
	public final void testAddCartItem() {
		cartDao.addCartItem(1, 2);
		cartDao.addCartItem(1, 3);
	}

	@Test
	public final void testGetAllCartItems() {
		List<MenuItem> cartItems = null;
		try {
			cartItems = cartDao.getAllCartItems(1);
		} catch (CartEmptyException e) {
			
		}
		for (Iterator iterator = cartItems.iterator(); iterator.hasNext();) {
			MenuItem menuItem = (MenuItem) iterator.next();
			System.out.println(menuItem);
		}
	}

	@Test
	public final void testRemoveCartItem() {
		fail("Not yet implemented");
	}

}
