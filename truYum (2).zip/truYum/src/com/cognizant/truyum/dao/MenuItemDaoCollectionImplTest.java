package com.cognizant.truyum.dao;

import static org.junit.Assert.fail;

import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cognizant.truyum.model.MenuItem;

public class MenuItemDaoCollectionImplTest {
	
	
	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public final void testMenuItemDaoCollectionImpl() {
		fail("Not yet implemented");
	}

	@Test
	public final void testGetMenuItemListAdmin() {
		MenuItemDao menuItemDao = new MenuItemDaoCollectionImpl();
		List<MenuItem> menuListItem = new ArrayList<>();
		menuListItem = menuItemDao.getMenuItemListAdmin();
		for (MenuItem menuItem : menuListItem) {
			System.out.println(menuItem);
		}
	}

	@Test
	public final void testGetMenuItemListCustomer() {
		MenuItemDao menuItemDao = new MenuItemDaoCollectionImpl();
		List<MenuItem> menuListItem = new ArrayList<>();
		menuListItem = menuItemDao.getMenuItemListCustomer();
		for (MenuItem menuItem : menuListItem) {
			System.out.println(menuItem);
		}
	}

	@Test
	public final void testModifyMenuItem() {
		fail("Not yet implemented");
	}

	@Test
	public final void testGetMenuItem() {
		fail("Not yet implemented");
	}

}
