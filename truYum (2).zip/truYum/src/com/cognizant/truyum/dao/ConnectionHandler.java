package com.cognizant.truyum.dao;

import java.sql.Connection;

public class ConnectionHandler {
	public static Connection getConnection() {
		// TODO: JDBC
		return null;

	}
}
