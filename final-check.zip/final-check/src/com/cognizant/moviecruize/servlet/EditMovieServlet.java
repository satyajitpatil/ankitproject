package com.cognizant.moviecruize.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cognizant.moviecruize.dao.MovieDao;
import com.cognizant.moviecruize.dao.MovieDaoCollectionImpl;
import com.cognizant.moviecruize.util.DateUtil;
import com.cognizant.moviecruize.model.Movie;

/**
 * Servlet implementation class EditMovieServlet
 */
@WebServlet("/EditMovie")
public class EditMovieServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EditMovieServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher rdMovie=request.getRequestDispatcher("edit-movie-status.jsp");
		Movie movie=new Movie();
		movie.setId(Long.parseLong(request.getParameter("id")));
		movie.setTitle(request.getParameter("title"));
		movie.setBoxOffice(Long.parseLong(request.getParameter("gross")));
		movie.setActive(Boolean.parseBoolean(request.getParameter("active")));
		movie.setDateOfLaunch(DateUtil.convertToDate(request.getParameter("dateoflaunch")));
		movie.setGenre(request.getParameter("genre"));
		movie.setHasTeaser(Boolean.parseBoolean(request.getParameter("hasTeaser")));
		MovieDao movieDao=new MovieDaoCollectionImpl();
		movieDao.modifyMovie(movie);
		rdMovie.forward(request, response);
		
	}

}
