package com.cognizant.moviecruize.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cognizant.moviecruize.dao.FavoriteDao;
import com.cognizant.moviecruize.dao.FavoriteDaoCollectionImpl;
import com.cognizant.moviecruize.dao.MovieDao;
import com.cognizant.moviecruize.dao.MovieDaoCollectionImpl;
import com.cognizant.moviecruize.model.Movie;

/**
 * Servlet implementation class AddToFavoriteServlet
 */
@WebServlet("/AddToFavoriteServlet")
public class AddToFavoriteServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public AddToFavoriteServlet() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	     List<Movie> movies = null;
	        MovieDao movieDao = null;
	        movieDao =  new MovieDaoCollectionImpl();
	        RequestDispatcher rDispatcher = request
	                     .getRequestDispatcher("movie-list-customer.jsp");
	        long userId = 1;
	        long movieId = Long.parseLong(request.getParameter("movieId"));
	        FavoriteDao favoriteDao = new FavoriteDaoCollectionImpl();
	        favoriteDao.addFavorite(title, movieId);
	        menuItems = menuItemDao.getMenuItemListCustomer();
	        request.setAttribute("msg", "Item Added Succesfully");
	        request.setAttribute("addCartStatus", true);
	        request.setAttribute("menuItems", menuItems);
	        rDispatcher.forward(request, response);
	        
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
