package com.cognizant.moviecruize.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cognizant.moviecruize.dao.FavoritesDao;
import com.cognizant.moviecruize.dao.FavoritesDaoCollectionImpl;
import com.cognizant.moviecruize.dao.MovieDao;
import com.cognizant.moviecruize.dao.MovieDaoCollectionImpl;
import com.cognizant.moviecruize.model.Movie;

/**
 * Servlet implementation class AddToFavoriteServlet
 */
@WebServlet("/AddToFavorite")
public class AddToFavoriteServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddToFavoriteServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher rdMovie=request.getRequestDispatcher("movie-list-customer.jsp");
		long userId=1;
		long movieId=Long.parseLong(request.getParameter("movieId"));
		FavoritesDao favoritesDao=new FavoritesDaoCollectionImpl();
		favoritesDao.addFavorites(userId, movieId);
		MovieDao movieDao=new MovieDaoCollectionImpl();
		List<Movie> movie=movieDao.getMovieListCustomer();
		request.setAttribute("movieList", movie);
		request.setAttribute("addFavoriteStatus", "Movie added to Favorites Successfully");
		rdMovie.forward(request, response);
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
