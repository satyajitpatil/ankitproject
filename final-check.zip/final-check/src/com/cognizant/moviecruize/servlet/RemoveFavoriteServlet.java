package com.cognizant.moviecruize.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cognizant.moviecruize.dao.FavoritesDao;
import com.cognizant.moviecruize.dao.FavoritesDaoCollectionImpl;
import com.cognizant.moviecruize.dao.NoFavoriteException;
import com.cognizant.moviecruize.model.Movie;

/**
 * Servlet implementation class RemoveFavoriteServlet
 */
@WebServlet("/RemoveFavorite")
public class RemoveFavoriteServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RemoveFavoriteServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		long movieId=Long.parseLong(request.getParameter("movieId"));
		FavoritesDao favoriteDao=new FavoritesDaoCollectionImpl();
		long userId=1;
		favoriteDao.removeFavorite(userId, movieId);
		List<Movie> movieList=null;
		int total=0;
		request.setAttribute("removeMovieStatus", "Movie removed from Favorites Successfully");
		try {
			RequestDispatcher rdMovie=request.getRequestDispatcher("favorites.jsp");
			movieList=favoriteDao.getAllFavorites(userId);
			request.setAttribute("favoriteList", movieList);
			for (Movie movie : movieList) {
				total+=1;
			}
			request.setAttribute("total", total);
			rdMovie.forward(request, response);
		} catch (NoFavoriteException e) {
			RequestDispatcher rdMovie=request.getRequestDispatcher("favorites-empty.jsp");
			rdMovie.forward(request, response);
		}
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
