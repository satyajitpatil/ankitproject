package com.cognizant.moviecruize.dao;

import java.util.List;

import com.cognizant.moviecruize.model.Movie;

public class MovieDaoSqlImpl implements MovieDao {

	@Override
	public List<Movie> viewMovieListAdmin() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Movie> viewMovieListCustomer() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Movie editMovie(Movie movie) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Movie viewMovie(int movieId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Movie viewMovie(long id) {
		// TODO Auto-generated method stub
		return null;
	}

}
