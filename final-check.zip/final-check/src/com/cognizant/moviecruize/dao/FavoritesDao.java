package com.cognizant.moviecruize.dao;

import java.util.List;

import com.cognizant.moviecruize.model.Movie;

public interface FavoritesDao {
	void addFavorites(long userId,long movieId);
	List<Movie> getAllFavorites(long userId) throws NoFavoriteException;
	void removeFavorite(long userId,long movieId);
	
}
