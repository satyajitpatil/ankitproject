package com.cognizant.moviecruize.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.cognizant.moviecruize.model.Movie;
import com.cognizant.moviecruize.util.DateUtil;

public class MovieDaoCollectionImpl implements MovieDao {
	
	private static List<Movie> movieList=null;
	 public MovieDaoCollectionImpl() {
		if(movieList==null){
			movieList=new ArrayList<>();
			Movie movieInstance=new Movie(1, "Avatar", 2787965087L, true, DateUtil.convertToDate("03/15/2017"),
					"Science Fiction", true);
			movieList.add(movieInstance);
			movieInstance=new Movie(2, "The Avengers", 1518812988L, true, DateUtil.convertToDate("12/23/2017"),
					"Superhero", false);
			movieList.add(movieInstance);
			movieInstance=new Movie(3, "Titanic", 2187463944L, true, DateUtil.convertToDate("08/21/2017"),
					"Romance", false);
			movieList.add(movieInstance);
			movieInstance=new Movie(4, "Jurassic World", 1671713208L, false, DateUtil.convertToDate("07/02/2017"),
					"Science Fiction", true);
			movieList.add(movieInstance);
			movieInstance=new Movie(5, "Avengers: End Game", 2570760348L, true, DateUtil.convertToDate("11/02/2022"),
					"Superhero", true);
			movieList.add(movieInstance);
		}
	}
	@Override
	public List<Movie> getMovieListAdmin() {
		return movieList;
	}
	

	@Override
	public List<Movie> getMovieListCustomer() {
		List<Movie> movieListCustomer = new ArrayList<>();
		for (Movie moviesList : movieList) {
			if (moviesList.isActive() == true && moviesList.getDateOfLaunch().compareTo(new Date()) <= 0) {
				movieListCustomer.add(moviesList);
			}
		}
		return movieListCustomer;
	}

	@Override
	public void modifyMovie(Movie movie) {
		movieList.set((int)movie.getId()-1, movie);
	}

	@Override
	public Movie getMovie(long movieId) {
		Movie item=null;
		for (Movie movie : movieList) {
			if(movie.getId()==movieId){
				item=movie;
				break;
			}
		}
		return item;
	}

}
