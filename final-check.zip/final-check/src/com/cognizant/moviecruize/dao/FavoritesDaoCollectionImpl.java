package com.cognizant.moviecruize.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.cognizant.moviecruize.model.Favorites;
import com.cognizant.moviecruize.model.Movie;


public class FavoritesDaoCollectionImpl implements FavoritesDao {
	private static HashMap<Long, Favorites> usersFavourites;
	private MovieDao movieDao;
	
	public FavoritesDaoCollectionImpl() {
		if(usersFavourites==null)
		{
			usersFavourites=new HashMap<>();
		}
		movieDao=new MovieDaoCollectionImpl();
	}

	@Override
	public void addFavorites(long userId, long movieId) {
		if(usersFavourites.containsKey(userId)){
			Favorites favorites=usersFavourites.get(userId);
			List<Movie> favoriteItems=favorites.getMovieList();
			Movie movie=movieDao.getMovie(movieId);
			
			int total=favorites.getTotal()+1;
			favoriteItems.add(movie);
			favorites=new Favorites(favoriteItems,total);
			usersFavourites.put(userId, favorites);
		} else {
			List<Movie> favoriteItems=new ArrayList<>();
			Movie movie=movieDao.getMovie(movieId);
			favoriteItems.add(movie);
			Favorites favorites=new Favorites(favoriteItems,1);
			usersFavourites.put(userId, favorites);
		}
	}

	@Override
	public List<Movie> getAllFavorites(long userId) throws NoFavoriteException {
		List<Movie> movieList=usersFavourites.get(userId).getMovieList();
		if(movieList.isEmpty())
		{
			throw new NoFavoriteException();
		}
		return movieList;
	}

	@Override
	public void removeFavorite(long userId, long movieId) {
		Movie movie=movieDao.getMovie(movieId);
		usersFavourites.get(userId).getMovieList().remove(movie);

	}

}
