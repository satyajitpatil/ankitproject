package com.cognizant.moviecruize.dao;

import java.util.List;

import com.cognizant.moviecruize.model.Movie;

public class FavoritesDaoSqlImpl implements FavoritesDao {

	@Override
	public void addFavorites(long userId, long movieId) {
		// TODO Auto-generated method stub

	}
	

	@Override
	public List<Movie> getAllFavorites(long userId) throws NoFavoriteException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void removeFavorite(long userid, long movieId) {
		// TODO Auto-generated method stub

	}

}
