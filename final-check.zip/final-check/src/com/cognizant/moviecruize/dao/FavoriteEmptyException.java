package com.cognizant.moviecruize.dao;

public class FavoriteEmptyException extends Exception {

	public FavoriteEmptyException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public FavoriteEmptyException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = -601876937927161416L;

}
