package com.cognizant.moviecruize.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cognizant.moviecruize.dao.FavoriteDao;
import com.cognizant.moviecruize.dao.FavoriteDaoCollectionImpl;
import com.cognizant.moviecruize.model.Movie;

/**
 * Servlet implementation class ShowFavoriteServlet
 */
@WebServlet("/ShowFavoriteServlet")
public class ShowFavoriteServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ShowFavoriteServlet() {
        super();
        // TODO Auto-generated constructor stub
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		                
		                                // TODO Auto-generated method stub
		                                FavoriteDao cd = new FavoriteDaoCollectionImpl();
		                                List<Movie> lm = null;
		                                long id = 1;
		                                try
		                                {
		                                                lm = cd.viewFavorites(id);
		                                                double sum = 0;
		                                                
		                                                for(Movie m:lm)
		                                                {
		                                                                sum = sum++;
		                                                }
		                                                request.setAttribute("sum", sum);
		                                                request.setAttribute("menuItem", lm);
		                                                request.setAttribute("EmptyMsg", "No movies in Favorite");
		                                                RequestDispatcher rd = request.getRequestDispatcher("favorite.jsp");
		                                                rd.forward(request, response);
		                                }catch(Exception e)
		                                {
		                                                
		                                }

		                }

	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
