package com.cognizant.moviecruize.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cognizant.moviecruize.dao.FavoriteDao;
import com.cognizant.moviecruize.dao.FavoriteDaoCollectionImpl;
import com.cognizant.moviecruize.model.Movie;


/**
 * Servlet implementation class RemoveFavoriteServlet
 */
@WebServlet("/RemoveFavoriteServlet")
public class RemoveFavoriteServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RemoveFavoriteServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		  FavoriteDao cd = new FavoriteDaoCollectionImpl();
          List<Movie> lm = null;
          long id = 1;
          long movieId= Long.parseLong(request.getParameter("menuItemId"));
          cd.removeFavorite(id, movieId);
          try
          {
                          lm = cd.viewFavorites(id);
          }catch(Exception e)
          {
                          
          }
         
          double sum =0;
          for(Movie m:lm)
          {
                       sum++;
                       
          }
          request.setAttribute("sum", sum);
          request.setAttribute("menuItem", lm);
          request.setAttribute("RemoveMsg", "Movies removed from favorite succesfully");
          request.setAttribute("EmptyMsg", "No items in cart");
          RequestDispatcher rd = request.getRequestDispatcher("favorite.jsp");
          rd.forward(request, response); }
	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
