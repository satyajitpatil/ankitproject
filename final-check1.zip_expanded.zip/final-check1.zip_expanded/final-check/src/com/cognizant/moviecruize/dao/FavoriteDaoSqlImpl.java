package com.cognizant.moviecruize.dao;

import java.util.List;

import com.cognizant.moviecruize.model.Movie;

public class FavoriteDaoSqlImpl implements FavoriteDao {

	@Override
	public void addFavorite(String title, int movieId) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void removeFavorite(String title, int movieId) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Movie> viewFavorites() {
		// TODO Auto-generated method stub
		return null;
	}

}
