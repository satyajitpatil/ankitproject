package com.cognizant.moviecruize.dao;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class FavoriteDaoSqlImplTest {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public final void testAddFavorite() {
		fail("Not yet implemented");
	}

	@Test
	public final void testRemoveFavorite() {
		fail("Not yet implemented");
	}

	@Test
	public final void testViewFavorites() {
		fail("Not yet implemented");
	}

}
