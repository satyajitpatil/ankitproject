package com.cognizant.moviecruize.dao;

import java.util.List;

import com.cognizant.moviecruize.model.Movie;

public interface FavoriteDao {
	void addFavorite(long userId, long movieId);
	void removeFavorite(long userId, long movieId);
	List<Movie> viewFavorites();
	List<Movie> viewFavorites(long userId);
}
