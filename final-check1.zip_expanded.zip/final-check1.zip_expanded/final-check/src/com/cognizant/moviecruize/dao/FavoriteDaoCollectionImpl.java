package com.cognizant.moviecruize.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cognizant.moviecruize.model.Favorites;
import com.cognizant.moviecruize.model.Movie;




public class FavoriteDaoCollectionImpl implements FavoriteDao {
	private static Map<Long,Favorites> userFavorites;
	private MovieDao movieDao;
	
	public FavoriteDaoCollectionImpl() {
		if(userFavorites==null)
		{
			userFavorites=new HashMap<>();
		}
	}
	
	@Override
	public void addFavorite(long userId, long movieId) {

		MovieDao movieDao = new MovieDaoCollectionImpl();
		Movie movie = movieDao.viewMovie(movieId);

		Favorites favorite = null;
		if (userFavorites.containsKey(userId)) {
			favorite = userFavorites.get(userId);
			List<Movie> favorites = favorite.getFavoriteList();
			favorites.add(movie);

			double total = favorite.getTotalFavorites() + movie.getBoxOffice();
			favorite.setFavoriteList(favorites);
			favorite.setTotalFavorites(total);
			userFavorites.put(userId, favorite);

		} else {
			List<Movie> favorites = new ArrayList<>();
			favorites.add(movie);
			favorite = new Favorites(favorites, movie.getBoxOffice());
			userFavorites.put(userId, favorite);
		}

		
	}

	@Override
	public void removeFavorite(long userId, long movieId) {
		Movie movie = movieDao.viewMovie(movieId);
		userFavorites.get(userId).getFavoriteList().remove(movie);

	}

	@Override
	public List<Movie> viewFavorites(long userId) {
		Favorites favorite = userFavorites.get(userId);
		List<Movie> favorites = favorite.getFavoriteList();
		return favorites;
	}

	@Override
	public List<Movie> viewFavorites() {
		// TODO Auto-generated method stub
		return null;
	}

}
